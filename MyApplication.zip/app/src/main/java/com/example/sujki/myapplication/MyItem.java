package com.example.sujki.myapplication;
import android.graphics.drawable.Drawable;
/**
 * Created by sujki on 2017-08-05.
 */

public class MyItem {
    private Drawable icon;
    private String name;
    private String contents;

    public Drawable getIcon() {
        return icon;
    }

    public void setIcon(Drawable icon) {
        this.icon = icon;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContents() {
        return contents;
    }


    public void setContents(String contents) {
        this.contents = contents;
    }

}

